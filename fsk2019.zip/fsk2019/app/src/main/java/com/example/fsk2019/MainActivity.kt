package com.example.fsk2019

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley

class MainActivity : AppCompatActivity() {
    lateinit var tv :TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tv = findViewById(R.id.textView)
        val ip = "192.168.43.197:8080"
        val queue = Volley.newRequestQueue(this)
        val eT: EditText = findViewById(R.id.editText)
        val gval : EditText = findViewById(R.id.editText2)
        val b: Button = findViewById(R.id.button)
        b.setOnClickListener{

            var urlc = "http://$ip/p/10000/"
            var req1 = eT.text

            var url = urlc + req1

            //  the RequestQueue.



            // Request a string response from the provided URL.
            val stringReq = StringRequest(Request.Method.GET, url,
                Response.Listener<String> { response ->

                    var strResp = response.toString()
                    tv.text = strResp

                },
                Response.ErrorListener { tv.text = "Error" })
            queue.add(stringReq)
        }
        val incB : Button = findViewById(R.id.inc)
        incB.setOnClickListener{
            var gvalt = gval.text.toString()
            var ivalt = (gvalt.toInt() + 10000).toString()
            var urlc = "http://$ip/i/$ivalt/"
            var req1 = eT.text

            var url = urlc + req1

            // Instantiate the RequestQueue.



            // Request a string response from the provided URL.
            val stringReq = StringRequest(Request.Method.GET, url,
                Response.Listener<String> { response ->

                    var strResp = response.toString()
                    tv.text = strResp

                },
                Response.ErrorListener { tv.text = "Error" })
            queue.add(stringReq)


        }
        val decB : Button = findViewById(R.id.dec)
        decB.setOnClickListener{
            var gvalt = gval.text.toString()
            var ivalt = (gvalt.toInt() + 10000).toString()
            var urlc = "http://$ip/d/$ivalt/"
            var req1 = eT.text

            var url = urlc + req1

            // Instantiate the RequestQueue.



            // Request a string response from the provided URL.
            val stringReq = StringRequest(Request.Method.GET, url,
                Response.Listener<String> { response ->

                    var strResp = response.toString()
                    tv.text = strResp

                },
                Response.ErrorListener { tv.text = "Error" })
            queue.add(stringReq)
        }
        val p: Button = findViewById(R.id.button2)
        p.setOnClickListener{
            var gvalt = gval.text.toString()
            var ivalt = (gvalt.toInt() + 10000).toString()
            var urlc = "http://$ip/q/$ivalt/"
            var req1 = eT.text

            var url = urlc + req1

            // Instantiate the RequestQueue.



            // Request a string response from the provided URL.
            val stringReq = StringRequest(Request.Method.GET, url,
                Response.Listener<String> { response ->

                    var strResp = response.toString()
                    tv.text = strResp

                },
                Response.ErrorListener { tv.text = "Error" })
            queue.add(stringReq)
        }

        }




}
